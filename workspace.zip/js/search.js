function addplus(items){
    var plussed = "";
    for (var t = 1; t<= items.length ; t++){
      if (items.substring(t-1,t) == " "){ 
        plussed+="+"; 
      }
      else{ 
        plussed+=items.substring(t-1,t); 
      }
    }
    return plussed;
  }

  function doSearch(){
    var words;
    words = document.searchforit.query.value;
    var searchitems;
    searchitems=addplus(words);
    var index;
    index = document.searchforit.service.selectedIndex;
    if (index>= 0) {
      var site;
      site = document.searchforit.service.options[index].value;
      site+=searchitems;
      site+=".html"
      if (notEmpty(searchitems)){
        window.open(site,"_self");
      }
    }
    else {
      alert("검색 엔진을 선택하세요.");
    }
  }

  function notEmpty(word)
  {
    if (word == "" || word == null){
      self.status="ENTER SEARCH searchitems";
      alert("검색어를 입력하세요.");
      document.searchforit.query.focus();
      return false;
    }
    else{
      self.status = word + "을(를) 찾고 있습니다.";
      return true;
    }
  }

  function clearIt(){
    document.searchforit.query.value="";
    document.searchforit.query.focus();
  }

  function FocusOn(){
    document.searchforit.query.focus();
    return;
  }