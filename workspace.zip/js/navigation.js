var nav = document.getElementsByClassName("navigation");
    
window.onscroll = function sticky() {
    if(window.pageYOffset > nav[0].offsetTop) {
    nav[0].classList.add("nav");
    } else {
    nav[0].classList.remove("nav");
    }
}
$(function(){
    $("iframe.myFrame").load(function(){
    var frame = $(this).get(0);
    var doc = (frame.contentDocument) ? frame.contentDocument : frame.contentWindow.document;
    $(this).height(doc.body.scrollHeight);
    $(this).width(doc.body.scrollWidth);
    });
});